#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

INSTALL_DIR="$HOME/.neriterm-server"
PLIST_NAME="com.neriterm.claude-server"
PLIST_PATH="$HOME/Library/LaunchAgents/$PLIST_NAME.plist"

echo -e "${YELLOW}=== NeriTerm Server Uninstaller ===${NC}"
echo ""

# Check if installed
if [ ! -d "$INSTALL_DIR" ] && [ ! -f "$PLIST_PATH" ]; then
    echo -e "${YELLOW}NeriTerm Server is not installed.${NC}"
    exit 0
fi

# Stop the service
echo -e "${YELLOW}Stopping service...${NC}"
launchctl unload "$PLIST_PATH" 2>/dev/null || true

# Remove LaunchAgent plist
if [ -f "$PLIST_PATH" ]; then
    rm -f "$PLIST_PATH"
    echo -e "  ${GREEN}Removed LaunchAgent${NC}"
fi

# Ask about server files
echo ""
read -p "Remove server files (dist, node_modules)? [y/N] " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    rm -rf "$INSTALL_DIR/dist"
    rm -rf "$INSTALL_DIR/node_modules"
    rm -f "$INSTALL_DIR/package.json"
    rm -f "$INSTALL_DIR/package-lock.json"
    echo -e "  ${GREEN}Server files removed${NC}"
fi

# Ask about configuration
echo ""
read -p "Remove configuration (.env)? [y/N] " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    rm -f "$INSTALL_DIR/.env"
    echo -e "  ${GREEN}Configuration removed${NC}"
fi

# Ask about logs
echo ""
read -p "Remove log files? [y/N] " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    rm -rf "$INSTALL_DIR/logs"
    echo -e "  ${GREEN}Logs removed${NC}"
fi

# Ask about data
echo ""
echo -e "${YELLOW}Warning: Data directory contains projects and device tokens.${NC}"
read -p "Remove ALL data (projects, uploads, keys)? [y/N] " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    rm -rf "$INSTALL_DIR/data"
    rm -rf "$INSTALL_DIR/uploads"
    rm -rf "$INSTALL_DIR/keys"
    echo -e "  ${GREEN}Data removed${NC}"
fi

# Check if directory is empty and remove it
if [ -d "$INSTALL_DIR" ]; then
    if [ -z "$(ls -A "$INSTALL_DIR" 2>/dev/null)" ]; then
        rmdir "$INSTALL_DIR"
        echo -e "  ${GREEN}Installation directory removed${NC}"
    else
        echo ""
        echo -e "${YELLOW}Some files remain in $INSTALL_DIR${NC}"
        echo "Remaining contents:"
        ls -la "$INSTALL_DIR"
    fi
fi

echo ""
echo -e "${GREEN}=== Uninstall Complete ===${NC}"
echo ""
echo "Thank you for using NeriTerm!"
echo "To reinstall, download the latest version from:"
echo "  https://github.com/nerikeshi/neriterm-server/releases"
