#!/bin/bash
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

INSTALL_DIR="$HOME/.neriterm-server"
PLIST_NAME="com.neriterm.claude-server"
PLIST_PATH="$HOME/Library/LaunchAgents/$PLIST_NAME.plist"

echo -e "${GREEN}=== NeriTerm Server Installer ===${NC}"
echo ""

# Check if running from correct directory
if [ ! -f "dist/index.js" ]; then
    echo -e "${RED}Error: dist/index.js not found.${NC}"
    echo "Please run this script from the extracted package directory."
    exit 1
fi

# Check Node.js installation
echo -e "${YELLOW}Checking requirements...${NC}"
if ! command -v node &> /dev/null; then
    echo -e "${RED}Error: Node.js is not installed.${NC}"
    echo ""
    echo "Install Node.js using one of these methods:"
    echo "  - Homebrew: brew install node"
    echo "  - Download: https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo -e "${RED}Error: Node.js 18 or higher is required.${NC}"
    echo "Current version: $(node -v)"
    echo ""
    echo "Update Node.js:"
    echo "  - Homebrew: brew upgrade node"
    echo "  - nvm: nvm install 18"
    exit 1
fi
echo -e "  Node.js: ${GREEN}$(node -v)${NC}"

# Check if already installed
if [ -d "$INSTALL_DIR" ]; then
    echo ""
    echo -e "${YELLOW}Warning: NeriTerm Server is already installed at $INSTALL_DIR${NC}"
    read -p "Do you want to reinstall? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Installation cancelled."
        exit 0
    fi

    # Stop existing service completely
    echo -e "  Stopping existing service..."
    launchctl unload "$PLIST_PATH" 2>/dev/null || true
    launchctl remove "$PLIST_NAME" 2>/dev/null || true
    sleep 1

    # Kill any remaining server processes on the configured port
    PORT=$(grep -E "^PORT=" "$INSTALL_DIR/.env" 2>/dev/null | cut -d= -f2 || echo "8080")
    lsof -ti :"${PORT:-8080}" 2>/dev/null | xargs kill 2>/dev/null || true
    sleep 1
fi

# Create installation directory
echo ""
echo -e "${YELLOW}Installing to $INSTALL_DIR...${NC}"
mkdir -p "$INSTALL_DIR"
mkdir -p "$INSTALL_DIR/logs"
mkdir -p "$INSTALL_DIR/data"
mkdir -p "$INSTALL_DIR/keys"
mkdir -p "$INSTALL_DIR/uploads"

# Copy files
cp -r dist "$INSTALL_DIR/"
cp -r node_modules "$INSTALL_DIR/"
cp package.json "$INSTALL_DIR/"

# Rebuild native modules for current architecture
echo -e "  Rebuilding native modules for $(uname -m)..."
cd "$INSTALL_DIR" && npm rebuild --silent 2>/dev/null
cd - > /dev/null

# Setup .env file
if [ ! -f "$INSTALL_DIR/.env" ]; then
    cp .env.example "$INSTALL_DIR/.env"

    # Generate secure AUTH_TOKEN
    AUTH_TOKEN=$(openssl rand -hex 32)

    # Update .env with generated token
    if [[ "$OSTYPE" == "darwin"* ]]; then
        sed -i '' "s/your-secure-random-token-32chars-min/$AUTH_TOKEN/" "$INSTALL_DIR/.env"
        sed -i '' "s|DEFAULT_WORKING_DIR=/Users/YOUR_USERNAME|DEFAULT_WORKING_DIR=$HOME|" "$INSTALL_DIR/.env"
    else
        sed -i "s/your-secure-random-token-32chars-min/$AUTH_TOKEN/" "$INSTALL_DIR/.env"
        sed -i "s|DEFAULT_WORKING_DIR=/Users/YOUR_USERNAME|DEFAULT_WORKING_DIR=$HOME|" "$INSTALL_DIR/.env"
    fi

    echo ""
    echo -e "${GREEN}========================================${NC}"
    echo -e "${GREEN}   AUTH_TOKEN Generated${NC}"
    echo -e "${GREEN}========================================${NC}"
    echo ""
    echo -e "Your authentication token:"
    echo ""
    echo -e "  ${CYAN}$AUTH_TOKEN${NC}"
    echo ""
    echo -e "${YELLOW}IMPORTANT: Save this token!${NC}"
    echo -e "You will need to enter it in the NeriTerm iOS app."
    echo ""
    echo -e "${GREEN}========================================${NC}"
else
    echo -e "  Using existing .env configuration"
fi

# Create LaunchAgent plist
echo ""
echo -e "${YELLOW}Setting up auto-start service...${NC}"

NODE_PATH=$(which node)
mkdir -p "$HOME/Library/LaunchAgents"

cat > "$PLIST_PATH" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>$PLIST_NAME</string>
    <key>ProgramArguments</key>
    <array>
        <string>$NODE_PATH</string>
        <string>$INSTALL_DIR/dist/index.js</string>
    </array>
    <key>WorkingDirectory</key>
    <string>$INSTALL_DIR</string>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>$INSTALL_DIR/logs/stdout.log</string>
    <key>StandardErrorPath</key>
    <string>$INSTALL_DIR/logs/stderr.log</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>/usr/local/bin:/usr/bin:/bin:/opt/homebrew/bin</string>
    </dict>
</dict>
</plist>
EOF

# Pre-flight check: verify server can start before registering with launchctl
echo ""
echo -e "${YELLOW}Verifying server can start...${NC}"

# Get configured port
SERVER_PORT=$(grep -E "^PORT=" "$INSTALL_DIR/.env" 2>/dev/null | cut -d= -f2 || echo "8080")

# Start server in background for testing
$NODE_PATH "$INSTALL_DIR/dist/index.js" &
TEST_PID=$!
sleep 3

# Check if process is still alive and responding
if kill -0 $TEST_PID 2>/dev/null && curl -s "http://localhost:${SERVER_PORT}/health" > /dev/null 2>&1; then
    echo -e "  ${GREEN}✓${NC} Server startup verified"
    kill $TEST_PID 2>/dev/null
    wait $TEST_PID 2>/dev/null
    sleep 1
else
    echo -e "  ${RED}✗ Server failed to start${NC}"
    kill $TEST_PID 2>/dev/null
    wait $TEST_PID 2>/dev/null

    echo ""
    echo -e "${RED}Error log:${NC}"
    cat "$INSTALL_DIR/logs/stderr.log" 2>/dev/null | tail -10
    echo ""
    echo -e "${YELLOW}Trying npm rebuild to fix native modules...${NC}"
    cd "$INSTALL_DIR" && npm rebuild 2>&1
    cd - > /dev/null

    # Retry after rebuild
    $NODE_PATH "$INSTALL_DIR/dist/index.js" &
    TEST_PID=$!
    sleep 3

    if kill -0 $TEST_PID 2>/dev/null && curl -s "http://localhost:${SERVER_PORT}/health" > /dev/null 2>&1; then
        echo -e "  ${GREEN}✓${NC} Server startup verified after rebuild"
        kill $TEST_PID 2>/dev/null
        wait $TEST_PID 2>/dev/null
        sleep 1
    else
        echo -e "  ${RED}✗ Server still cannot start${NC}"
        kill $TEST_PID 2>/dev/null
        wait $TEST_PID 2>/dev/null
        echo ""
        echo "Please check the error log:"
        echo "  cat $INSTALL_DIR/logs/stderr.log"
        echo ""
        echo "Common fixes:"
        echo "  - cd $INSTALL_DIR && npm rebuild"
        echo "  - Ensure Node.js $(node -v) is compatible"
        exit 1
    fi
fi

# Load the service (server is verified to work)
> "$INSTALL_DIR/logs/stderr.log"
> "$INSTALL_DIR/logs/stdout.log"
launchctl load "$PLIST_PATH"

# Wait for server to start
echo ""
echo -e "${YELLOW}Starting server...${NC}"
sleep 3

# Check if server is running
if curl -s "http://localhost:${SERVER_PORT}/health" > /dev/null 2>&1; then
    echo -e "${GREEN}Server is running!${NC}"
else
    echo -e "${YELLOW}Server may still be starting...${NC}"
    echo "Check logs: tail -f $INSTALL_DIR/logs/stderr.log"
fi

# Configure Claude Code Hooks
echo ""
echo -e "${YELLOW}Configuring Claude Code Hooks...${NC}"

CLAUDE_DIR="$HOME/.claude"
CLAUDE_SETTINGS="$CLAUDE_DIR/settings.json"

# Create .claude directory if it doesn't exist
mkdir -p "$CLAUDE_DIR"

# Use Node.js to safely merge JSON
node << 'NODEJS_SCRIPT'
const fs = require('fs');
const path = require('path');

const settingsPath = path.join(process.env.HOME, '.claude', 'settings.json');

// NeriTerm hook command
const hookCommand = 'curl -s -X POST http://localhost:8080/hook -H "Content-Type: application/json" -d "$(cat)" 2>/dev/null || true';

// NeriTerm hooks configuration (ALL hooks use nested format with matcher)
const neriTermHooks = {
  Stop: [{
    matcher: '*',
    hooks: [{ type: 'command', command: hookCommand }]
  }],
  Notification: [{
    matcher: 'permission_prompt|idle_prompt',
    hooks: [{ type: 'command', command: hookCommand }]
  }],
  PreToolUse: [{
    matcher: '*',
    hooks: [{ type: 'command', command: hookCommand }]
  }]
};

// Check if a hook is a NeriTerm hook (handles both flat and nested formats)
function isNeriTermHook(hook) {
  if (!hook) return false;
  // Flat format: { type, command }
  if (hook.command && hook.command.includes('localhost:8080/hook')) {
    return true;
  }
  // Nested format: { matcher, hooks: [{ type, command }] }
  if (hook.hooks && Array.isArray(hook.hooks)) {
    return hook.hooks.some(h => h.command && h.command.includes('localhost:8080/hook'));
  }
  return false;
}

// Merge hooks arrays, replacing NeriTerm hooks
function mergeHookArrays(existing, neriTermHook) {
  if (!existing || !Array.isArray(existing)) {
    return neriTermHook;
  }
  // Remove existing NeriTerm hooks
  const filtered = existing.filter(hook => !isNeriTermHook(hook));
  // Add new NeriTerm hooks
  return [...filtered, ...neriTermHook];
}

try {
  let settings = {};

  // Read existing settings
  if (fs.existsSync(settingsPath)) {
    const content = fs.readFileSync(settingsPath, 'utf8');
    try {
      settings = JSON.parse(content);
    } catch (e) {
      console.error('Warning: Could not parse existing settings.json, creating backup');
      fs.copyFileSync(settingsPath, settingsPath + '.backup');
      settings = {};
    }
  }

  // Initialize hooks object if not exists
  if (!settings.hooks) {
    settings.hooks = {};
  }

  // Merge each hook type
  for (const [hookType, neriTermHook] of Object.entries(neriTermHooks)) {
    settings.hooks[hookType] = mergeHookArrays(settings.hooks[hookType], neriTermHook);
  }

  // Write updated settings
  fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2) + '\n');
  console.log('Claude Code Hooks configured successfully');

} catch (error) {
  console.error('Error configuring Claude Code Hooks:', error.message);
  process.exit(1);
}
NODEJS_SCRIPT

if [ $? -eq 0 ]; then
    echo -e "  ${GREEN}✓${NC} Claude Code Hooks configured at $CLAUDE_SETTINGS"
else
    echo -e "  ${RED}✗${NC} Failed to configure Claude Code Hooks"
    echo -e "  ${YELLOW}You can manually add hooks later. See documentation.${NC}"
fi

# Print summary
echo ""
echo -e "${GREEN}=== Installation Complete ===${NC}"
echo ""
echo "Installation directory: $INSTALL_DIR"
echo "Configuration file:     $INSTALL_DIR/.env"
echo "Log files:              $INSTALL_DIR/logs/"
echo ""
echo "Server endpoints:"
echo "  - Health check: http://localhost:8080/health"
echo "  - Status page:  http://localhost:8080/status"
echo "  - Hook endpoint: http://localhost:8080/hook"
echo ""
echo "Claude Code Hooks: $CLAUDE_SETTINGS"
echo ""
echo -e "${YELLOW}Next steps:${NC}"
echo "  1. Configure Tailscale for remote access"
echo "  2. Open NeriTerm app on your iPhone"
echo "  3. Enter your Tailscale IP and AUTH_TOKEN"
echo "  4. Restart Claude Code to apply hooks"
echo ""
echo "Useful commands:"
echo "  - View logs:    tail -f $INSTALL_DIR/logs/stderr.log"
echo "  - Stop server:  launchctl unload $PLIST_PATH"
echo "  - Start server: launchctl load $PLIST_PATH"
echo "  - Uninstall:    ./uninstall.sh"
echo ""
echo -e "${CYAN}For push notifications (optional):${NC}"
echo "  1. Get Firebase service account key from Firebase Console"
echo "  2. Place it at: $INSTALL_DIR/keys/firebase-service-account.json"
echo "  3. Restart server: launchctl unload $PLIST_PATH && launchctl load $PLIST_PATH"
