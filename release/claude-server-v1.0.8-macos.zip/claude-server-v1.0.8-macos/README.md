# NeriTerm Server

NeriTerm iOS アプリ用のコンパニオンサーバーです。
MacでClaude Codeを実行し、iPhoneからリモートアクセスを可能にします。

## 必要環境

- **macOS** 12.0 (Monterey) 以降
- **Node.js** 18.0 以降
- **Tailscale** (リモートアクセス用、推奨)

## クイックスタート

### 1. インストール

```bash
# ZIPを展開した後、インストールスクリプトを実行
./install.sh
```

インストールスクリプトが実行されると：
- サーバーが `~/.neriterm-server` にインストールされます
- 認証トークン (AUTH_TOKEN) が自動生成されます
- macOS起動時に自動起動するよう設定されます

**重要**: 表示されるAUTH_TOKENは必ず保存してください。NeriTermアプリで必要になります。

### 2. 動作確認

ブラウザで以下にアクセス：
```
http://localhost:8080/status
```

または、ターミナルで：
```bash
curl http://localhost:8080/health
```

### 3. Tailscaleの設定（リモートアクセス用）

1. [Tailscale](https://tailscale.com/) をインストール
2. Tailscaleにログイン
3. MacのTailscale IPアドレスを確認 (例: `100.x.x.x`)
4. NeriTermアプリでこのIPアドレスを入力

> **セキュリティ上の注意**: このサーバーはTailscale VPN経由での接続を前提として設計されています。Tailscale内のWireGuardが通信を暗号化するため、サーバー自体はHTTPで動作します。**サーバーを公開インターネットに直接公開しないでください。**

## 設定

設定ファイル: `~/.neriterm-server/.env`

```bash
# サーバー設定
PORT=8080
AUTH_TOKEN=your-auth-token-here

# Firebase設定（プッシュ通知用、オプション）
FIREBASE_SERVICE_ACCOUNT_PATH=./keys/firebase-service-account.json

# ターミナル設定
DEFAULT_SHELL=/bin/zsh
DEFAULT_WORKING_DIR=/Users/your-username
```

### プッシュ通知の設定（オプション）

プッシュ通知を有効にするには：

1. [Firebase Console](https://console.firebase.google.com/) でプロジェクトを作成
2. プロジェクト設定 > サービスアカウント > 新しい秘密鍵を生成
3. ダウンロードしたJSONファイルを `~/.neriterm-server/keys/firebase-service-account.json` に配置
4. サーバーを再起動

```bash
launchctl unload ~/Library/LaunchAgents/com.neriterm.claude-server.plist
launchctl load ~/Library/LaunchAgents/com.neriterm.claude-server.plist
```

## コマンド

```bash
# サーバーの状態確認
curl http://localhost:8080/health

# ログを確認
tail -f ~/.neriterm-server/logs/stderr.log

# サーバーを停止
launchctl unload ~/Library/LaunchAgents/com.neriterm.claude-server.plist

# サーバーを起動
launchctl load ~/Library/LaunchAgents/com.neriterm.claude-server.plist

# サーバーを再起動
launchctl unload ~/Library/LaunchAgents/com.neriterm.claude-server.plist && \
launchctl load ~/Library/LaunchAgents/com.neriterm.claude-server.plist

# アンインストール
./uninstall.sh
```

## NeriTermアプリでの接続

1. NeriTermアプリを開く
2. サーバー設定画面で以下を入力：
   - **ホスト**: `localhost`（同じMac）または Tailscale IP（リモート）
   - **ポート**: `8080`
   - **AUTH_TOKEN**: インストール時に表示されたトークン
3. 「接続」をタップ

## トラブルシューティング

### サーバーが起動しない

```bash
# ログを確認
tail -100 ~/.neriterm-server/logs/stderr.log

# Node.jsのバージョンを確認
node -v  # 18以上であること
```

### 接続できない

1. サーバーが起動しているか確認：
   ```bash
   curl http://localhost:8080/health
   ```

2. ファイアウォールの設定を確認（システム環境設定 > セキュリティとプライバシー）

3. Tailscale経由の場合、両方のデバイスがTailscaleに接続されているか確認

### AUTH_TOKENを忘れた

```bash
# .envファイルからトークンを確認
cat ~/.neriterm-server/.env | grep AUTH_TOKEN
```

新しいトークンを生成したい場合：
```bash
# 新しいトークンを生成
openssl rand -hex 32
# 生成されたトークンを.envファイルに設定し、サーバーを再起動
```

## ディレクトリ構造

```
~/.neriterm-server/
├── dist/                  # サーバーコード
├── node_modules/          # 依存関係
├── data/                  # プロジェクト・デバイストークンのデータ
├── keys/                  # Firebase認証キー（オプション）
├── logs/                  # ログファイル
├── uploads/               # アップロードされた画像
└── .env                   # 設定ファイル
```

## アンインストール

```bash
./uninstall.sh
```

アンインストールスクリプトは以下を確認しながら削除します：
- サービスの停止
- サーバーファイル
- 設定ファイル
- ログ
- データ（プロジェクト、アップロード）

## サポート

問題が発生した場合：
- [GitHub Issues](https://github.com/nerikeshi/neriterm-server/issues)
- Email: nerikeshi.cola@gmail.com

## ライセンス

MIT License - 詳細は LICENSE ファイルを参照してください。
